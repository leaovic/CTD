
# Sign Up Form

Sign Up page using HTML and CSS.<br />
This project was made for a youtube tutorial.<br /><br/>
**Youtube link: https://youtu.be/jAr98quOZMY**
### Web Version
<img src="assets/final.png" alt="Web Version"/>

### Mobile Version
<img src="assets/final-mobile.png" alt="Mobile Version"/>

## 🚀 Starting

To start the project, just open the file `index.html` in your preferred browser.

---
##### Coded with love by Giovanna Moeller ♥️
